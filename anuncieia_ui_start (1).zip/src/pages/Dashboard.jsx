import React from 'react';

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <h1 className="text-3xl font-semibold mb-4">Painel AnuncieIA</h1>
      <p>Em breve: criação de anúncios, análise de concorrência e muito mais...</p>
    </div>
  );
}