# AnuncieIA

Plataforma SaaS Beta para geração automática de anúncios.

## Como usar

1. `npm install`
2. `npm run dev` (desenvolvimento)
3. `npm run build` (produção)
