import React from 'react';

export default function App() {
  return (
    <div style={{ padding: '2rem', textAlign: 'center' }}>
      <h1>Bem-vindo ao AnuncieIA Beta</h1>
      <p>Aqui você controla seu SaaS de anúncios automáticos.</p>
    </div>
  );
}
